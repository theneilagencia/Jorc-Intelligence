from flask import Flask

def create_app():
    app = Flask(__name__)

    # Importar blueprints dos módulos
    from app.modules.radar.routes import radar_bp
    from app.modules.reports.routes import reports_bp
    from app.modules.audit.routes import audit_bp
    from app.modules.bridge.routes import bridge_bp
    from app.modules.admin.routes import admin_bp

    app.register_blueprint(radar_bp, url_prefix="/radar")
    app.register_blueprint(reports_bp, url_prefix="/reports")
    app.register_blueprint(audit_bp, url_prefix="/audit")
    app.register_blueprint(bridge_bp, url_prefix="/bridge")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    @app.route("/")
    def home():
        return {"status": "QIVO backend modular running 🚀", "mode": "production"}

    return app

app = create_app()
